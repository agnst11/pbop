from penyewaan import sepeda, cur

s = sepeda

data = s.showItem()

print(data)